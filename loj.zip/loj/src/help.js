const help = (prefix) => { 
	return `🔹🅿🆄🅳🅸🅳🅸🔹

● *Status* : *Online*
● *Fitur* : *157 Fitur*
● *User* : *@${num.split('@')[0]}*

╔▣━━❨°❀ＰＯＰＵＬＡＲ❀°❩━▣⊱┓
║┃
║┣➤ *${prefix}film* <bujang lapok>
║┣➤ *${prefix}suggest*
║┣➤ *${prefix}sticker*
║┣➤ *${prefix}tsticker*
║┣➤ *${prefix}toimg*
║┣➤ *${prefix}tts <kode bhs><teks>*
║┃
┣▣━━━❨°❀ＯＷＮＥＲ❀°❩━━━▣⊱┓
║┃
║┣➤ *${prefix}bc* 
║┣➤ *${prefix}leave*
║┣➤ *${prefix}clearall*
║┣➤ *${prefix}setprefix*
║┣➤ *${prefix}clone* [tag]
║┣➤ *${prefix}block*
║┣➤ *${prefix}unblock*
║┣➤ *${prefix}getses*
║┃
┣▣━━━❨°❀ＧＲＯＵＢ❀°❩━━━▣⊱┓
║┃
║┣➤ *${prefix}add* [62xxx]
║┣➤ *${prefix}kick* [tag]
║┣➤ *${prefix}setpp*
║┣➤ *${prefix}setname*
║┣➤ *${prefix}setdesc*
║┣➤ *${prefix}demote* [tag]
║┣➤ *${prefix}promote* [tag]
║┣➤ *${prefix}tagall*
║┣➤ *${prefix}group* [buka/tutup]
║┣➤ *${prefix}welcome* [1/0]
║┣➤ *${prefix}nsfw* [1/0]
║┣➤ *${prefix}simih* [1/0]
║┣➤ *${prefix}linkgroup*
║┣➤ *${prefix}listadmins*
║┣➤ *${prefix}groupinfo
║┣➤ *${prefix}hidetag*
║┣➤ *${prefix}tagme*
║┣➤ *${prefix}delete*
║┣➤ *${prefix}report <lapor masalah>*
║┃
┣▣━━━━❨°❀ＬＯＧＯ❀°❩━━━━▣⊱┓
║┃
║┣➤ *${prefix}bmetal <teks>*
║┣➤ *${prefix}matrix <teks>*
║┣➤ *${prefix}text3d <teks>*
║┣➤ *${prefix}ninja <teks|teks>*
║┣➤ *${prefix}wolf <teks|teks>*
║┣➤ *${prefix}wolf2 <teks|teks>*
║┣➤ *${prefix}lion <teks|teks>*
║┣➤ *${prefix}textscreen <teks>*
║┣➤ *${prefix}tahta <teks>*
║┣➤ *${prefix}blackpink <teks>*
║┣➤ *${prefix}rtext <teks>*
║┣➤ *${prefix}thunder <teks>*
║┣➤ *${prefix}glitch <teks | teks>*
║┣➤ *${prefix}marvel <teks | teks>*
║┣➤ *${prefix}watercolor <teks | teks>*
║┣➤ *${prefix}party <teks>*
║┣➤ *${prefix}lovemake <teks>*
║┣➤ *${prefix}galaxtext <teks>*
║┣➤ *${prefix}pron <teks>*
║┣➤ *${prefix}embun <teks>*
║┣➤ *${prefix}dark <teks>*
║┣➤ *${prefix}silktxt <teks>*
║┣➤ *${prefix}quotemaker <teks>*
║┣➤ *${prefix}gneon <teks>*
║┣➤ *${prefix}snow <teks|teks>*
║┣➤ *${prefix}glow <teks>*
║┣➤ *${prefix}leaves <teks>*
║┣➤ *${prefix}joker <teks>*
║┃
┣▣━━━━━❨°❀ＦＵＮ❀°❩━━━━▣⊱┓
║┃
║┣➤ *${prefix}lirik <judul lagu>*
║┣➤ *${prefix}quotes*
║┣➤ *${prefix}bucin*
║┣➤ *${prefix}gay*
║┣➤ *${prefix}ssweb*
║┣➤ *${prefix}url2img*
║┣➤ *${prefix}shorturl*
║┣➤ *${prefix}walpaperhd*
║┣➤ *${prefix}meme*
║┣➤ *${prefix}memeindo*
║┣➤ *${prefix}hilih*
║┣➤ *${prefix}watak*
║┣➤ *${prefix}simi*
║┣➤ *${prefix}say* <teks>
║┣➤ *${prefix}namaninja* <nama>
║┣➤ *${prefix}rate*
║┣➤ *${prefix}inu*
║┣➤ *${prefix}image <nama>*
║┣➤ *${prefix}indohot*
║┣➤ *${prefix}randomcat*
║┣➤ *${prefix}nolep*
║┣➤ *${prefix}ganteng*
║┃
┣▣━━━❨°❀ＡＧＡＭＡ❀°❩━━━▣⊱┓
║┃
║┣➤ *${prefix}sholat <nama daerah>*
║┣➤ *${prefix}surah <nomor surah>*
║┣➤ *${prefix}tafsir <tentang apa>*
║┣➤ *${prefix}asmaul <nomor 1 - 99>*
║┣➤ *${prefix}alkitab*
║┣➤ *${prefix}renungan*
║┃
┣▣━━━❨°❀ＥＤＵＣＡ❀°❩━━━▣⊱┓
║┃
║┣➤ *${prefix}nulis <teks>*
║┣➤ *${prefix}nulis2 <teks|nama|kelas>*
║┣➤ *${prefix}brainly* <soalan>
║┣➤ *${prefix}dictionary* <room>
║┣➤ *${prefix}wiki* <ikan>
║┣➤ *${prefix}wikien* <fish>
║┣➤ *${prefix}kbbi* <cari apa>
║┣➤ *${prefix}apakah*
║┣➤ *${prefix}bisakah*
║┣➤ *${prefix}kapankah*
║┃
┣▣━━━━❨°❀ＧＡＭＥ❀°❩━━━▣⊱┓
║┃
║┣➤ *${prefix}tebakgambar*
║┣➤ *${prefix}caklontong*
║┣➤ *${prefix}family100*
║┣➤ *${prefix}game*
║┣➤ *${prefix}truth*
║┣➤ *${prefix}dare*
║┃
┣▣━━━━❨°❀ＮＳＦＷ❀°❩━━━▣⊱┓
║┃
║┣➤ *${prefix}randomhentai*
║┣➤ *${prefix}nsfwtrap*
║┣➤ *${prefix}nsfwneko*
║┣➤ *${prefix}nsfwblowjob*
║┃
┣▣━❨°❀ＤＯＷＮＬＯＡＤ❀°❩━▣⊱┓
║┃
║┣➤ *${prefix}ytsearch* [search yt]
║┣➤ *${prefix}ytmp3* [link]
║┣➤ *${prefix}ytmp4* [link]
║┣➤ *${prefix}tiktok* [link]
║┃
┣▣━━━❨°❀ＭＥＤＩＡ❀°❩━━━▣⊱┓
║┃
║┣➤ *${prefix}igstalk* <namaig>
║┣➤ *${prefix}map* <nama daerah>
║┣➤ *${prefix}playstore*
║┣➤ *${prefix}joox*
║┣➤ *${prefix}ytsearch* <cari apa>
║┣➤ *${prefix}tiktokstalk*
║┣➤ *${prefix}spcall* <821xxx>
║┣➤ *${prefix}spgmail* <a@gmail.com>
║┃
┣▣━━━❨°❀ＲＡＭＡＬ❀°❩━━━▣⊱┓
║┃
║┣➤ *${prefix}primbonjodoh <nama>|<nama>*
║┣➤ *${prefix}artinama <nama>*
║┣➤ *${prefix}ramalhp <nomor>*
║┣➤ *${prefix}mimpi <mimpi apa>*
║┣➤ *${prefix}zodiak <nama zodiak>*
║┣➤ *${prefix}ramaljadian <tgl|bln|thn>*
║┃
┣▣━━━━❨°❀ＩＮＦＯ❀°❩━━━▣⊱┓
║┃
║┣➤ *${prefix}covidind*
║┣➤ *${prefix}pinterest <cari apa>*
║┣➤ *${prefix}jam <nama daerah>*
║┣➤ *${prefix}alamat <jip1 medan>*
║┣➤ *${prefix}tv <nama channel>*
║┣➤ *${prefix}mlherolist*
║┣➤ *${prefix}heroml* <nama hero>
║┣➤ *${prefix}infonomor* <nomor hp>
║┣➤ *${prefix}infomotor* <nama kreta>
║┣➤ *${prefix}infohp* <nama hp>
║┣➤ *${prefix}infomobil* <nama mobil>
║┣➤ *${prefix}blocklist*
║┣➤ *${prefix}infogempa*
║┣➤ *${prefix}infogithub*
║┣➤ *${prefix}infocuaca*
║┣➤ *${prefix}resepmasakan* <nama>
║┣➤ *${prefix}creator*
║┣➤ *${prefix}speed*
║┃
┣▣━━━━❨°❀ＷＩＢＵ❀°❩━━━▣⊱┓
║┃
║┣➤ *${prefix}nekonime*
║┣➤ *${prefix}randomanime*
║┣➤ *${prefix}wait* <put foto yg dicari>
║┣➤ *${prefix}anime*
║┣➤ *${prefix}loli*
║┣➤ *${prefix}waifu*
║┣➤ *${prefix}pokemon*
║┣➤ *${prefix}quotanime*
║┣➤ *${prefix}movie* <nama film>
║┃
┣▣━━━━❨°❀ＭＯＲＥ❀°❩━━━▣⊱┓
║┃
║┣➤ *${prefix}donasi*
║┣➤ *${prefix}info*
║┃
┣━━━━━━━━━━━━━━━━━━━━
║     🔹ＢＯＴ ＢＹ ＡＤＡＭ🔹
╚━━━━━━━━━━━━━━━━━━━━`
}
exports.help = help